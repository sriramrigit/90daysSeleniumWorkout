package steps4trivago;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Steps {
	ChromeDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	Actions action;

	@Given("Trivago site loaded")
	public void trivagoSiteLoaded() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver();
		driver.get("https://www.trivago.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,150)", "");
		Thread.sleep(2000);
	}

	@And("Type Agra in Destination and select Agra, Uttar Pradesh")
	public void typeAgraInDestinationAndSelectAgraUttarPradesh() throws InterruptedException {
		WebElement destination = driver.findElementById("querytext");
		destination.clear();
		destination.sendKeys("Agra", Keys.DOWN, Keys.TAB);
		Thread.sleep(2000);
	}

	@And("Choose June15 as check in and June30 as check out")
	public void chooseJuneAsCheckInAndJuneAsCheckOut() throws InterruptedException {

		/*
		 * WebElement startdate =
		 * driver.findElementByXPath("//span[@class='icon-ic dealform-button__icon']");
		 * startdate.click(); Thread.sleep(2000);
		 *//*
			 * JavascriptExecutor js = (JavascriptExecutor) driver;
			 * js.executeScript("window.scrollBy(0, 250)");
			 */
		/*
		 * driver.findElementByXPath(
		 * "//table[@class='cal-month']/tbody[1]/tr[3]/td[1]/time[1]").click();
		 * Thread.sleep(1000); WebElement enddate =
		 * driver.findElementByXPath("(//time[@class='dealform-button__label'])[2]");
		 * enddate.click(); Thread.sleep(2000); driver.findElementByXPath(
		 * "//table[@class='cal-month']/tbody[1]/tr[5]/td[2]/time[1]").click();
		 */

		Thread.sleep(2000);
		driver.findElement(By.xpath("//time[@datetime='2020-06-19']")).click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("//time[@datetime='2020-06-30']")).click();
		Thread.sleep(1000);

	}

	@And("Select Room as Family Room")
	public void selectRoomAsFamilyRoom() throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='Family rooms']")).click();
		Thread.sleep(1000);

	}

	@And("Choose Number of Adults {int}, Childern {int} and set Child's Age as {int}")
	public void chooseNumberOfAdultsChildernAndSetChildSAgeAs(Integer int1, Integer int2, Integer int3)
			throws InterruptedException {

		WebElement adults = driver.findElement(By.xpath("(//select[@class='df-select'])[1]"));
		Select selectAdults = new Select(adults);
		selectAdults.selectByVisibleText("2");
		WebElement children = driver.findElement(By.xpath("(//select[@class='df-select'])[2]"));
		Select selectChildren = new Select(children);
		selectChildren.selectByVisibleText("1");
		Thread.sleep(1000);
		WebElement childrenAge = driver.findElement(By.xpath("//select[@class='df-select js-select-child-age']"));
		Select selectChildrenAge = new Select(childrenAge);
		selectChildrenAge.selectByVisibleText("4");
	}

	@And("Click Confirm button and click Search")
	public void clickConfirmButtonAndClickSearch() throws InterruptedException {
		driver.findElement(By.xpath("//span[text()='Confirm']")).click();
		Thread.sleep(1000);
		driver.findElementByXPath("//span[text()='Search']").click();
		System.out.println("Search button clicked");

	}

	@And("Select Accommodation type as Hotels only and choose 4 stars")
	public void selectAccommodationTypeAsHotelsOnlyAndChooseStars() throws InterruptedException {
		WebElement Accommodation = driver.findElement(By.xpath("//strong[text()='Accommodation']"));
		Actions builder = new Actions(driver);
		builder.moveToElement(Accommodation).perform();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//label[text()='Hotels only']")).click();
		Thread.sleep(1000);
		driver.findElementByXPath("//div[@class='refinement-row__content']//button[@title='4-star hotels']").click();
		Thread.sleep(1000);
		driver.findElementById("filter-popover-done-button").click();

	}

	@And("Select Guest rating as Very Good")
	public void selectGuestRatingAsVeryGood() throws InterruptedException {
		WebElement guestRating = driver.findElement(By.xpath("//strong[text()='Guest rating']"));
		Thread.sleep(1000);
		Actions builder = new Actions(driver);
		builder.moveToElement(guestRating).perform();
		driver.findElement(By.xpath("//span[text()='Very good']")).click();
		Thread.sleep(1000);
	}

	@And("Set Hotel Location as Agra Fort and click Done")
	public void setHotelLocationAsAgraFortAndClickDone() throws InterruptedException {
		WebElement hotelLocation = driver.findElement(By.xpath("//strong[text()='Hotel location']"));
		Actions builder = new Actions(driver);
		builder.moveToElement(hotelLocation).perform();
		Thread.sleep(1000);
		WebElement location = driver.findElement(By.xpath("//select[@id='pois']"));
		Select selectLocation = new Select(location);
		selectLocation.selectByVisibleText("Agra Fort");
		driver.findElement(By.xpath("//button[text()='Done']")).click();
	}

	@And("In more Filters, select Air conditioning, Restaurant and WiFi and click Done")
	public void inMoreFiltersSelectAirConditioningRestaurantAndWiFiAndClickDone() throws InterruptedException {
		WebElement moreFilters = driver.findElement(By.xpath("//span[text()='Select']"));
		Actions builder = new Actions(driver);
		builder.moveToElement(moreFilters).perform();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//label[text()='Air conditioning']")).click();
		driver.findElement(By.xpath("//label[text()='WiFi']")).click();
		driver.findElement(By.xpath("//label[text()='Restaurant']")).click();
		driver.findElement(By.xpath("//button[text()='Done']")).click();
	}

	@And("Sort the result as Rating & Recommended")
	public void sortTheResultAsRatingRecommended() {
		WebElement sortBy = driver.findElement(By.xpath("//select[@id='mf-select-sortby']"));
		Select selectSortBy = new Select(sortBy);
		selectSortBy.selectByVisibleText("Rating & Recommended");
	}

	@Then("Print the Hotel name, Rating, Number of Reviews and Click View Deal")
	public void printTheHotelNameRatingNumberOfReviewsAndClickViewDeal() {
		WebElement contents = driver.findElement(By.xpath("(//span[@class='item-link name__copytext'])[1]"));
		wait=new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.visibilityOf(contents));
		System.out.println("Hotel Name is : "
				+ driver.findElement(By.xpath("(//span[@class='item-link name__copytext'])[1]")).getText());
		System.out.println(
				"Rating is : " + driver.findElement(By.xpath("(//span[@itemprop='ratingValue'])[1]")).getText());
		System.out.println("Number of Reviews is : " + driver
				.findElement(By.xpath("(//span[contains(text(),'reviews')])[1]")).getText().replaceAll("[^0-9]", ""));
		driver.findElement(By.xpath("(//span[text()='View Deal'])[1]")).click();

	}

	@Then("Print the URL of the Page")
	public void printTheURLOfThePage() throws InterruptedException {
		List<String> list = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(list.get(1));
		// wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//span[text()='Close']")))).click();
		System.out.println("Curent URL is: " + driver.getCurrentUrl());
		Thread.sleep(1000);
	}

	@Then("Print the Price of the Room and click Choose Your Room")
	public void printThePriceOfTheRoomAndClickChooseYourRoom() {
		 WebElement price = driver.findElement(By.xpath("(//div[@class='bui-price-display__value prco-text-nowrap-helper prco-inline-block-maker-helper'])[1]"));
		    System.out.println("Price in US$ = "+price.getText().replaceAll("[^0-9]", ""));
		    driver.findElement(By.xpath("(//a[@class='txp-cta bui-button bui-button--primary sr_cta_button'])[1]")).click();
	}

	@Then("Click Reserve and I'll Reserve")
	public void clickReserveAndILlReserve() throws InterruptedException {
		driver.findElement(By.xpath("(//button[@id='hp_book_now_button'])[1]")).click();
	    WebElement Rooms = driver.findElement(By.xpath("(//select[@class='hprt-nos-select'])[1]"));
	    wait.until(ExpectedConditions.visibilityOf(Rooms));
	    Select selectRooms = new Select(Rooms);
	    selectRooms.selectByValue("1");
	    Thread.sleep(1000);
	    driver.findElement(By.xpath("//div[@class='hprt-reservation-cta']")).click();
	}

	@Then("Close the browser")
	public void closeTheBrowser() {
		driver.quit();

	}

}
