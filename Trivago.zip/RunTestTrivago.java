package runner4trivago;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "src/main/java/features/Trivago.feature", 
					glue = "steps4trivago", 
					monochrome = true, 
					snippets = SnippetType.CAMELCASE, 
					plugin = {"pretty", "html:reports" }
				)
public class RunTestTrivago extends AbstractTestNGCucumberTests {

}
