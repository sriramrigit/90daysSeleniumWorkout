package runner4Shopclues;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "src/main/java/features/ShopClues.feature", 
					glue = "steps4ShopClues",
					monochrome = true, 
					snippets = SnippetType.CAMELCASE, 
					plugin = {"pretty", "html:reports" }
				)
public class RunTestShopClues extends AbstractTestNGCucumberTests {

}
