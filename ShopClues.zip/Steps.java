package steps4ShopClues;

import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps {

	ChromeDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	Actions action;

	@Given("Go to shopclues site")
	public void goToShopcluesSite() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver(options);
		driver.get("https://www.shopclues.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(2000);

	}

	@Then("Mouseover on women and click Casual Shoes")
	public void mouseoverOnWomenAndClickCasualShoes() throws InterruptedException {

		WebElement women = driver.findElementByLinkText("WOMEN");
		action = new Actions(driver);
		action.moveToElement(women).perform();
		WebElement casual = driver
				.findElementByXPath("//a[@alt='Home|CT4P1|WOMEN|NA|Footwear|Casual Shoes|NA|NA|CT@Casual Shoes']");
		action.moveToElement(casual).click().perform();
		Thread.sleep(2000);
	}

	@And("Select Color as Black")
	public void selectColorAsBlack() throws InterruptedException {
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> list = new ArrayList<String>(windowHandles);
		driver.switchTo().window(list.get(1));
		Thread.sleep(5000);
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 260)");
		WebElement blackfilter = driver.findElementByXPath("//label[@for='Black']");
		js.executeScript("arguments[0].click()", blackfilter);
		Thread.sleep(2000);
	}

	@When("Check whether the product name contains the word black")
	public void checkWhetherTheProductNameContainsTheWordBlack() {
		WebElement blackfilter = driver.findElementByXPath("//span[text()='Black']");
		String text = blackfilter.getText();
		if (text.contains("Black")) {
			System.out.println("Black shoes are displayed");
		}
	}

	@Then("If so, add the product name and price in to Map")
	public void ifSoAddTheProductNameAndPriceInToMap() {

		WebElement firstProduct = driver.findElementByXPath("//i[@class='made-in-india']/following-sibling::span[1]");
		String productName = firstProduct.getText();
		WebElement price = driver.findElementByXPath("//span[text()='Rs.419']");
		String pricevalue = price.getText();
		Map<String, String> map = new LinkedHashMap<String, String>();
		map.put(productName, pricevalue);
		Set<Entry<String, String>> entrySet = map.entrySet();
		for (Entry<String, String> entry : entrySet) {
			System.out.println("Model --> " + entry.getKey() + " Price --> " + entry.getValue());
		}
	}

	@And("Check Display the count of shoes which are more than 500rupees")
	public void checkDisplayTheCountOfShoesWhichAreMoreThanRupees() throws InterruptedException {
		WebElement gt500 = driver.findElementByXPath("//label[@for='Rs. 500 - Rs. 999']");
		js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", gt500);
		Thread.sleep(2000);
		WebElement total = driver.findElementByXPath("//span[text()='74 Products Found']");
		String lt500 = total.getText().replaceAll("[^0-9]", "");
		System.out.println("Total no of black shoes :" + lt500);

	}

	@And("Click the highest price of the shoe")
	public void clickTheHighestPriceOfTheShoe() throws InterruptedException {
		driver.findElementByLinkText("High Price").click();
		Thread.sleep(2000);
		driver.findElementByXPath(
				"//img[@data-img='https://cdn.shopclues.com/images/thumbnails/87503/320/1/130598207IMG91921510747840.jpg']")
				.click();
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> list = new ArrayList<String>(windowHandles);
		driver.switchTo().window(list.get(2));
	}

	@And("Get the current page URL and check with the product ID")
	public void getTheCurrentPageURLAndCheckWithTheProductID() {
		String currentUrl = driver.getCurrentUrl().replaceAll("[^0-9]", "");
		WebElement pid = driver.findElementByClassName("pID");
		if (currentUrl.equals(pid.getText())) {
			System.out.println("Product id matches with url");
		}

	}

	@And("Copy the offercode")
	public void copyTheOffercode()
			throws RuntimeException, UnsupportedFlavorException, IOException, InterruptedException {
		driver.findElementById("first__B2G75").click();
		Thread.sleep(1000);
		String localClipboardData = (String) Toolkit.getDefaultToolkit().getSystemClipboard()
				.getData(DataFlavor.stringFlavor);
		System.out.println("offercode value is: " + localClipboardData);
	}

	@And("Select size, color and click ADD TO CART")
	public void selectSizeColorAndClickADDTOCART() throws InterruptedException {
		driver.findElementByXPath("//span[@class='variant var ']").click();
		Thread.sleep(2000);
		driver.findElementById("add_cart").click();
		Thread.sleep(2000);
	}

	@And("Mouse over on Shopping cart and click View Cart")
	public void mouseOverOnShoppingCartAndClickViewCart() throws InterruptedException {
		WebElement cart = driver.findElementByClassName("cart_icon_count");
		action.moveToElement(cart).perform();
		driver.findElementByXPath("//a[contains(@class,'btn orange-white')]").click();
		Thread.sleep(2000);
	}

	@And("Type Pincode as-600016 click Submit and Place Order")
	public void typePincodeAsClickSubmitAndPlaceOrder() throws InterruptedException {
		WebElement pincode = driver.findElementById("pin_code_popup");
		pincode.clear();
		pincode.sendKeys("600016");
		driver.findElementById("get_pincode_popup").click();
		Thread.sleep(2000);
		driver.findElementByXPath("//div[@class='btn orange']").click();
	}

	@Then("Close the Browser")
	public void closeTheBrowser() {
		driver.quit();
	}

}
