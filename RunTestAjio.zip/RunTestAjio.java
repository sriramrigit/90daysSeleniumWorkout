package runner4Ajio;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "src/main/java/features/Ajio.feature", 
					glue = "steps4Ajio",
					monochrome = true, 
					snippets = SnippetType.CAMELCASE, 
					plugin = {"pretty", "html:reports" }
				)
public class RunTestAjio extends AbstractTestNGCucumberTests {

}
