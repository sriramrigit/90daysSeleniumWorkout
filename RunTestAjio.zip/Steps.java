package steps4Ajio;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps {

	ChromeDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	Actions action;

	@Given("Ajio site is launched")
	public void ajioSiteIsLaunched() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver(options);
		driver.get("https://www.ajio.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(2000);
		driver.findElementByXPath("(//img[@class='btn-cat-nav img-animate'])[1]").click();
		Thread.sleep(2000);
		try {
			driver.findElementByClassName("ic-close-quickview").click();
		} catch (WebDriverException e) {
			System.out.println("No such window exists");
		}
	}

	@And("Mouseover on Women, CATEGORIES and click on Kurtas")
	public void mouseoverOnWomenCATEGORIESAndClickOnKurtas() {
		WebElement women = driver.findElementByXPath("//a[@href='/shop/women']");
		Actions builder = new Actions(driver);
		builder.moveToElement(women).perform();
		driver.findElementByXPath("(//a[@title='Kurtas'])[2]").click();
	}

	@And("Click on Brands and choose Ajio")
	public void clickOnBrandsAndChooseAjio() throws InterruptedException {

		driver.findElementByXPath("(//div[@class='facet-head '])[2]").click();
		Thread.sleep(1000);
		driver.findElementByXPath("//label[@for='AJIO']").click();
		Thread.sleep(2000);
	}

	@And("Check all the results are Ajio")
	public void checkAllTheResultsAreAjio() {
		String text = driver.findElementByClassName("pull-left").getText();
		if (text.contentEquals("AJIO")) {
			System.out.println("Ajio products displayed");
		}

	}

	@And("Set Sort by the result as Discount")
	public void setSortByTheResultAsDiscount() throws InterruptedException {

		WebElement discount = driver.findElementByXPath("//div[@class='filter-dropdown']//select[1]");
		Select dis = new Select(discount);
		dis.selectByVisibleText("Discount");
		Thread.sleep(5000);
	}

	@And("Select the Color and click ADD TO BAG")
	public void selectTheColorAndClickADDTOBAG() throws InterruptedException {
		driver.findElementByXPath("(//div[@class='imgHolder']//img)[1]").click();
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> windowHandlesList = new ArrayList<String>(windowHandles);
		driver.switchTo().window(windowHandlesList.get(1));
		System.out.println("Current URL: " + driver.getCurrentUrl());
		Thread.sleep(2000);
		driver.findElementByXPath("//img[@class='swatch-image swatch-image-notselected']").click();
		Thread.sleep(2000);
		
	}

	@When("Verify the error message Select your size to know your estimated delivery date")
	public void verifyTheErrorMessageSelectYourSizeToKnowYourEstimatedDeliveryDate() throws InterruptedException {
		driver.findElementByClassName("btn-gold").click();
		Thread.sleep(2000);
		String errTxt = driver.findElementByXPath("//span[text()='Please select a size']").getText();
		if(errTxt.contains("Please select a size"))
		{
			System.out.println("Error message displayed"+errTxt);
		}
		
	}

	@Then("Select size and click ADD TO BAG")
	public void selectSizeAndClickADDTOBAG() throws InterruptedException {
		driver.findElementByXPath("//div[contains(@class,'circle size-variant-item')]").click();
		Thread.sleep(2000);
	}

	@Then("click on Enter pin-code to know estimated delivery date")
	public void clickOnEnterPinCodeToKnowEstimatedDeliveryDate() throws InterruptedException {
		driver.findElementByXPath("//span[contains(@class,'edd-pincode-msg-details edd-pincode-msg-details-pointer')]").click();
		WebElement pincode = driver.findElementByName("pincode");
		js= (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", pincode);
		pincode.sendKeys("603103",Keys.ENTER);
		Thread.sleep(2000);
		String delivery = driver.findElementByClassName("edd-message-success-details-highlighted").getText();
		System.out.println("Estimated delivery date :"+delivery);
	}

	@Then("Enter the pincode as 603103 and click Confirm pincode")
	public void enterThePincodeAsAndClickConfirmPincode() throws InterruptedException {
		driver.findElementByXPath("//span[text()='ADD TO BAG']").click();
		Thread.sleep(2000);

	}

	@Then("Print the message and click Go to  Bag")
	public void printTheMessageAndClickGoToBag() throws InterruptedException {
		WebElement gotobag = driver.findElementByXPath("//span[text()='GO TO BAG']");
		wait=new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.textToBePresentInElement(gotobag, "GO TO BAG"));
		gotobag.click();
		
	}

	@Then("Click on Proceed to Shipping and clode the browser")
	public void clickOnProceedToShippingAndClodeTheBrowser() {
		driver.findElementByXPath("//button[text()='Proceed to shipping']").click();
		driver.quit();
	}

}
