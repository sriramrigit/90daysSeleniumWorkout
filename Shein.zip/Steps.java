package steps4Shein;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Steps {
	ChromeDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	Actions action;
	
	@Given("open shein site")
	public void openSheinSite() throws InterruptedException {
				
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver(options);
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(CapabilityType.UNHANDLED_PROMPT_BEHAVIOUR, UnexpectedAlertBehaviour.DISMISS);
		options.merge(cap);
		driver.get("https://www.shein.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(5000);
		WebElement popup = driver.findElementByXPath("//div[@class='c-coupon-box']//i[1]");
		js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click()", popup);
	    
	}

	@Then("Mouseover on Clothing and click Jeans")
	public void mouseoverOnClothingAndClickJeans() throws InterruptedException {
		WebElement clothing = driver.findElementByXPath("//span[text()='CLOTHING']");
		action=new Actions(driver);
		action.moveToElement(clothing).perform();
		WebElement jeans = driver.findElementByLinkText("Jeans");
		action.moveToElement(jeans).click().perform();
		Thread.sleep(2000);
	   
	    
	}

	@Then("Choose Black under Jeans product count")
	public void chooseBlackUnderJeansProductCount() throws InterruptedException {
	   WebElement black = driver.findElementByLinkText("Black");
	   black.click();
	   Thread.sleep(2000);
	   js=(JavascriptExecutor)driver;
	   js.executeScript("window.scrollBy(0, 260)");
	   	    
	}

	@Then("check size as medium")
	public void checkSizeAsMedium() throws InterruptedException {
		js = (JavascriptExecutor) driver;
		WebElement size = driver.findElementByXPath("//span[text()='Size']");
		js.executeScript("arguments[0].click();", size);
	   WebElement medium = driver.findElementByXPath("//a[@data-attr-value_id='417']//span[1]");
	   js.executeScript("arguments[0].click();", medium);
	   Thread.sleep(2000);
	   
	}

	@Then("Click + in color")
	public void clickInColor() {
	   
	    
	}

	@Then("check whether the color is black")
	public void checkWhetherTheColorIsBlack() {
		WebElement mouseover = driver.findElementByXPath("(//a[@class='j-auto-attrlink']/span)[5]");
		   action=new Actions(driver);
		   action.moveToElement(mouseover).perform();
		   System.out.println(mouseover.getText());
		   
	    
	}

	@Then("Click first item to Add to Bag")
	public void clickFirstItemToAddToBag() throws InterruptedException {
	 //  WebElement first = driver.findElementByXPath("//img[@data-src='//img.ltwebstatic.com/images3_pi/2020/05/26/15904612784d90dec87d37d77b08a06a04ed41cecc_thumbnail_405x552.jpg']");
		/*
		 * action=new Actions(driver); action.moveToElement(first).perform(); driver.
		 * findElementByXPath("//button[text()[normalize-space()='+ Add to Bag']]").
		 * click(); Thread.sleep(2000);
		 */
		WebElement firstItem = driver
				.findElement(By.xpath("(//img[@class='c-goodsitem__secimg j-goodsitem__secimg'])[1]"));
		js.executeScript("arguments[0].click();", firstItem);
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> whList = new ArrayList<String>(windowHandles);
		driver.switchTo().window(whList.get(1));
		Thread.sleep(1000);
	    
	}

	@Then("Click the size as M abd click Submit")
	public void clickTheSizeAsMAbdClickSubmit() throws InterruptedException {
		/*
		 * driver.findElementByXPath(
		 * "html>body>div>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div:nth-of-type(4)>div>div:nth-of-type(2)>div>div:nth-of-type(2)>div>div>label:nth-of-type(3)>span"
		 * ).click(); driver.findElementByXPath(
		 * "//div[@class='j-quick-add-opt-1235904']/following-sibling::button[1]").click
		 * (); Thread.sleep(2000);
		 */
		driver.findElementByXPath("//span[@class='inner' and text()[normalize-space()='M']]").click();
		driver.findElementByXPath("(//button[@class='she-btn-black she-btn-xl'])[1]").click();
	}

	@Then("Click view Bag")
	public void clickViewBag() throws InterruptedException {
		/*
		 * js=(JavascriptExecutor)driver; js.executeScript("window.scrollBy(260, 0)");
		 */
		WebElement viewcart = driver.findElementByXPath("//i[@class='iconfont-critical icon-gouwudai']");
		action=new Actions(driver);
		action.moveToElement(viewcart).perform();
		//.findElementByLinkText("view bag").click();
		action.click(driver.findElementByXPath("//a[text()='view bag']")).perform();
	    Thread.sleep(2000);
	}

	@Then("Check the size is Medium or not.")
	public void checkTheSizeIsMediumOrNot() {
	   WebElement getsize = driver.findElementByXPath("//span[@class='gd-size']/em");
	    if(getsize.getAttribute("class")=="M")
	    {
	    	System.out.println("size is M");
	    }
	}

	@Then("Close the browser")
	public void closeTheBrowser() {
	   driver.close();
	    
	}

}
