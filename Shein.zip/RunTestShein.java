package runner4Shein;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "src/main/java/features/Shein.feature", 
					glue = "steps4Shein",
					monochrome = true, 
					snippets = SnippetType.CAMELCASE, 
					plugin = {"pretty", "html:reports" }
				)
public class RunTestShein extends AbstractTestNGCucumberTests {

}
