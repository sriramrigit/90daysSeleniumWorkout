package steps4BigBasket;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Steps extends Base {
	
	/*
	 * WebDriverWait wait; JavascriptExecutor js; Actions builder;
	 */
	@Given("BigBasket site is launched")
	public void bigbasketSiteIsLaunched() throws InterruptedException {
		/*
		 * System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		 * ChromeOptions options = new ChromeOptions();
		 * options.addArguments("--disable-notifications"); driver = new
		 * ChromeDriver(options); driver.get("https://www.bigbasket.com/");
		 * driver.manage().window().maximize();
		 * driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 * Thread.sleep(2000);
		 */
		System.out.println("before step is called here from Hooks");
	}

	@Given("mouse over on  Shop by Category")
	public void mouseOverOnShopByCategory() throws InterruptedException {
		WebElement shopBy = driver.findElementByXPath("//a[@class='dropdown-toggle meganav-shop']");
		Actions builder = new Actions(driver);
		builder.moveToElement(shopBy).perform();
		Thread.sleep(2000);

	}

	@Given("Go to FOODGRAINS, OIL & MASALA and RICE & RICE PRODUCTS")
	public void goToFOODGRAINSOILMASALAAndRICERICEPRODUCTS() throws InterruptedException {

		WebElement foodgrain = driver.findElementByXPath("(//a[@href='/cl/foodgrains-oil-masala/?nc=nb'])[2]");
		builder = new Actions(driver);
		Thread.sleep(2000);
		builder.moveToElement(foodgrain).perform();
		WebElement rice = driver
				.findElementByXPath("(//a[@ng-href='/pc/foodgrains-oil-masala/rice-rice-products/?nc=nb'])[2]");
		builder.moveToElement(rice).perform();
		Thread.sleep(2000);
	}
	@Then("Go to Beverages and Fruit juices & Drinks")
	public void goToBeveragesAndFruitJuicesDrinks() throws InterruptedException {
	   WebElement beverages = driver.findElementByXPath("(//a[@href='/cl/beverages/?nc=nb'])[2]");
	   builder = new Actions(driver);
	   Thread.sleep(2000);
	   builder.moveToElement(beverages).perform();
	   WebElement jd = driver.findElementByXPath("(//a[@ng-href='/pc/beverages/fruit-juices-drinks/?nc=nb'])[2]");
	   builder = new Actions(driver);
	   builder.moveToElement(jd).perform();
	    
	}
	@Then("Click on JUICES And click Tropicana and Real under Brand")
	public void clickOnJUICESAndClickTropicanaAndRealUnderBrand() throws InterruptedException {
	   WebElement juices = driver.findElementByXPath("(//a[@ng-href='/pc/beverages/fruit-juices-drinks/juices-sweetened/?nc=nb'])[2]");
	   builder = new Actions(driver);
	   Thread.sleep(2000);
	   builder.moveToElement(juices).click().perform();
	   Thread.sleep(2000);
	   WebElement searchBrand = driver.findElementByXPath("(//input[@ng-model='vm.brandSearch'])[1]");
	   searchBrand.clear();
	   searchBrand.sendKeys("Tropicana");
	   Thread.sleep(5000);
	   driver.findElementByXPath("(//span[text()='Tropicana'])[1]").click();
	   searchBrand.clear();
	   searchBrand.sendKeys("Real");
	   Thread.sleep(5000);
	   driver.findElementByXPath("(//span[text()='Real'])[1]").click();
	   Thread.sleep(5000);
	}
	@Then("Check count of the products from each Brands and total count")
	public void checkCountOfTheProductsFromEachBrandsAndTotalCount() throws InterruptedException {
	   WebElement total = driver.findElementByXPath("(//h2[@class='ng-binding'])[3]");
	   String totaljuice=total.getText();
	   driver.findElementByXPath("(//span[@class='clearfilter'])[2]").click();
	   Thread.sleep(5000);
	   WebElement totalafterremoval = driver.findElementByXPath("(//h2[@class='ng-binding'])[3]");
	   Thread.sleep(5000);
	   String totaltropicana=totalafterremoval.getText();
	   System.out.println("Total juices :"+totaljuice+"Tropicana juices :"+totaltropicana);
	    
	}
	

	@Given("Click on BOILED & STEAM RICE")
	public void clickOnBOILEDSTEAMRICE() throws InterruptedException {
		WebElement boiled = driver.findElementByXPath("(//a[@ng-bind='l3.name'])[5]");
		Actions builder = new Actions(driver);
		builder.moveToElement(boiled).click().perform();
		Thread.sleep(2000);

	}

	@Given("Get the URL of the page and check with site navigation link")
	public void getTheURLOfThePageAndCheckWithSiteNavigationLink() {
		String currentUrl = driver.getCurrentUrl();
		// System.out.println(currentUrl);
		String att = driver.findElementByXPath("/html/body/div[1]/div[2]/div/div[4]/a").getAttribute("href");
		// System.out.println(att);

		if ((currentUrl.substring(0, currentUrl.length() - 2).equalsIgnoreCase(att.substring(0, att.length() - 2)))) {
			System.out.println(
					"we are currently in HOME > FOODGRAINS, OIL & MASALA> RICE & RICE PRODUCTS> BOILED & STEAM RICE)");
		}

	}

	@Given("Choose the Brand as bb Royal")
	public void chooseTheBrandAsBbRoyal() throws InterruptedException {
		driver.findElementByXPath("(//span[text()='bb Royal'])[1]").click();
		Thread.sleep(2000);

	}

	@Given("Go to Ponni Boiled Rice and select 10kg bag from Dropdown")
	public void goToPonniBoiledRiceAndSelectKgBagFromDropdown() throws InterruptedException {
		driver.findElementByXPath("(//span[text()='(12 - 17 Months Old)'])[1]").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//a[@href='#'])[3]").click();
		Thread.sleep(2000);
	}
	@Then("Check whether the products is availabe with Add button")
	public void checkWhetherTheProductsIsAvailabeWithAddButton() {
	 WebElement check = driver.findElementByXPath("(//span[@class='bskt-icon'])[1]");
	 if(check.isDisplayed())
	 {
		 System.out.println("Add button is visible");
	 }
	    
	}
	@Then("Add the First listed available product")
	public void addTheFirstListedAvailableProduct() throws InterruptedException {
		driver.findElementByXPath("(//span[@class='bskt-icon'])[1]").click();
		Thread.sleep(3000);
		try {
			driver.findElementByLinkText("Continue").click();
		} catch (WebDriverException e) {
			System.out.println("Address popup not displayed");
		}
		Thread.sleep(2000);

	    
	}


	@Given("Click Add button")
	public void clickAddButton() throws InterruptedException {
		/*
		 * js=(JavascriptExecutor)driver; js.executeScript("window.scrollBy(0,250)");
		 */
		driver.findElementByXPath("(//span[@class='bskt-icon'])[1]").click();
		Thread.sleep(3000);
		try {
			driver.findElementByLinkText("Continue").click();
		} catch (WebDriverException e) {
			System.out.println("Address popup not displayed");
		}
		Thread.sleep(2000);
	}

	@Then("Go to search box and type Dal")
	public void goToSearchBoxAndTypeDal() throws InterruptedException {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(250,0)");
		WebElement search = driver.findElementById("input");
		search.sendKeys("dal");
		Thread.sleep(2000);

	}

	@Then("Add Toor-Arhar Dal 2kg and set Qty2 from the list")
	public void addToorArharDalKgAndSetQtyFromTheList() throws InterruptedException {

		WebElement tdall = driver.findElementByXPath(
				"//div[@id='search-found']/div[1]/div[1]/div[1]/div[1]/ul[1]/li[8]/div[1]/div[7]/div[1]/input[1]");
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(tdall));
		tdall.clear();
		tdall.sendKeys("2", Keys.TAB);
		driver.findElementByXPath(
				"//div[@id='search-found']/div[1]/div[1]/div[1]/div[1]/ul[1]/li[8]/div[1]/div[8]/button[1]").click();
		Thread.sleep(4000);
		Actions build = new Actions(driver);
		build.moveToElement(driver.findElement(By.xpath("(//span[text()='bb Royal'])[1]"))).perform();
	}

	@Then("click Address")
	public void clickAddress() throws InterruptedException {

		/*
		 * driver.findElementByXPath("(//span[@class='ng-binding'])[3]").click();
		 * Thread.sleep(2000);
		 */
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-300)", "");
		WebElement address = driver.findElement(By.xpath("//span[@class='hvc']"));
		js.executeScript("arguments[0].click()", address);

	}
	@Then("click on Change Address")
	public void clickOnChangeAddress() {
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-300)", "");
		WebElement address = driver.findElement(By.xpath("//span[@class='hvc']"));
		js.executeScript("arguments[0].click()", address);
	    
	}

	
	@Then("Select CHennai as City, Alandur-600016,Chennai as Area  and click Continue")
	public void selectCHennaiAsCityAlandurChennaiAsAreaAndClickContinue() throws InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-200)");
		driver.findElement(By.xpath("(//span[@class='btn btn-default form-control ui-select-toggle'])[1]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//a[@class='ui-select-choices-row-inner'])[5]")).click();
		WebElement area = driver.findElement(By.id("areaselect"));
		area.sendKeys("Alandur", Keys.DOWN, Keys.TAB);
		Thread.sleep(2000);
		driver.findElementByXPath("//button[text() = 'Continue']").click();
		/*
		 * 
		 * driver.findElement(By.
		 * xpath("(//span[@class='btn btn-default form-control ui-select-toggle'])[1]"))
		 * .click(); Thread.sleep(2000);
		 * driver.findElement(By.xpath("(//a[@class='ui-select-choices-row-inner'])[5]")
		 * ).click(); WebElement area = driver.findElement(By.id("areaselect"));
		 * area.sendKeys("Alandur"); area.sendKeys(Keys.DOWN,Keys.TAB);
		 * Thread.sleep(1000); driver.findElement(By.name("continue")).click();
		 */
		Thread.sleep(2000);

	}

	@Then("Mouse over on My Basket take a screen shot")
	public void mouseOverOnMyBasketTakeAScreenShot() throws IOException {
		WebElement basket = driver.findElementByXPath("//a[@qa='myBasket']");
		Actions builder = new Actions(driver);
		builder.moveToElement(basket).perform();
		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile = new File("src/main/java/screenshot.png");
		FileUtils.copyFile(SrcFile, DestFile);
	}
	@Then("Mouse over on My Basket print the product name count and price")
	public void mouseOverOnMyBasketPrintTheProductNameCountAndPrice() {
		WebElement basket = driver.findElementByXPath("//a[@qa='myBasket']");
		Actions builder = new Actions(driver);
		builder.moveToElement(basket).perform();
		WebElement prodname = driver.findElementByXPath("(//a[@href='#'])[2]");
		WebElement count = driver.findElementByXPath("//input[contains(@class,'text-change-qty-search-popup ng-pristine')]");
		WebElement price = driver.findElementByXPath("(//span[@class='ng-binding'])[4]");
		System.out.println(prodname.getText()+count.getText()+price.getText());
	    
	}

	@Then("Click View Basket and Checkout")
	public void clickViewBasketAndCheckout() throws InterruptedException {
		driver.findElementByXPath("//button[@qa='viewBasketMB']").click();
		Thread.sleep(2000);
	}

	@Then("Click the close button and close the browser")
	public void clickTheCloseButtonAndCloseTheBrowser() {
		/*
		 * WebElement dismiss =
		 * driver.findElementByXPath("//button[@class='close'])[1]"); js =
		 * (JavascriptExecutor) driver; js.executeScript("arguments[0].click()",
		 * dismiss); driver.quit();
		 */
		// driver.findElementByXPath("//button[@qa= 'viewBasketMB']").click();
		driver.findElementByXPath("//button[@class ='close']").click();
		

	}

}
