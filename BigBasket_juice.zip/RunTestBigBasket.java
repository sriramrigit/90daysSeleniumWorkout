package runner4BigBasket;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "src/main/java/features/BigBasket.feature", 
					glue = "steps4BigBasket",
					monochrome = true, 
					tags="@functional",
					snippets = SnippetType.CAMELCASE, 
					plugin = {"pretty", "html:reports" }
				)
public class RunTestBigBasket extends AbstractTestNGCucumberTests {

}
