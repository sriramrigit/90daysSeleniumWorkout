package steps4BigBasket;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Base {
	
	public static ChromeDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
	Actions builder;


}
